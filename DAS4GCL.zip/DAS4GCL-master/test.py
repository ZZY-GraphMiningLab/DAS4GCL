import dgl
import torch
import torch.nn as nn
import torch.nn.functional as F

print("dgl version:",dgl.__version__)
# 创建图数据
g = dgl.graph(([0, 1, 1, 2, 3], [1, 2, 3, 0, 4]))  # 边的关系作为元组传递
features = torch.tensor([[0.2, 0.4], [0.1, 0.3], [-0.2, 0.5], [0.3, 0.2], [0.4, -0.1]], dtype=torch.float)  # 设置节点特征
labels = torch.tensor([0, 1, 0, 1, 0], dtype=torch.long)  # 设置标签
g.ndata['h'] = features

# 定义GCN模型
class GCN(nn.Module):
    def __init__(self, in_feats, hidden_size, num_classes):
        super(GCN, self).__init__()
        self.fc1 = nn.Linear(in_feats, hidden_size)
        self.fc2 = nn.Linear(hidden_size, num_classes)

    def forward(self, g, features):
        h = self.fc1(features)
        h = torch.relu(h)
        h = self.fc2(h)
        return h

# 创建并初始化模型
model = GCN(in_feats=2, hidden_size=16, num_classes=2)
optimizer = torch.optim.Adam(model.parameters(), lr=0.01)

# 训练模型
def train():
    model.train()
    optimizer.zero_grad()
    logits = model(g, g.ndata['h'])
    loss = F.cross_entropy(logits, labels)
    loss.backward()
    optimizer.step()
    return loss.item()

# 迭代训练若干次
for epoch in range(100):
    loss = train()
    print('Epoch {}, Loss: {}'.format(epoch, loss))
