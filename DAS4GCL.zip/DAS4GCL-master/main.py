import argparse
import os.path as osp
import random
import nni
import yaml
from yaml import SafeLoader
import numpy as np
# import scipy
import torch
from torch_geometric.utils import dropout_path
from model import Encoder, GRACE
from functional import drop_node_features_by_index, drop_feature
from eval import log_regression, MulticlassEvaluator
from utils import get_base_model, get_activation
from dataset import get_dataset

from torch_geometric.nn import GCNConv
from sklearn.manifold import TSNE



def euclidean_distance(vector1, vector2):
    vector11 = vector1.flatten()  # 将矩阵展开成向量
    vector22 = vector2.flatten()  # 将矩阵展开成向量

    squared_diff = np.square(vector11 - vector22)
    distance = np.sqrt(np.sum(squared_diff))
    return distance


def train():
    model.train()
    optimizer.zero_grad()
    # edge_index_1 = dropout_edge(data.edge_index, p=drop_edge_rate_1)[0]
    # edge_index_2 = dropout_edge(data.edge_index, p=drop_edge_rate_2)[0]
    edge_index_3, walk_nodes1 = dropout_path(data.edge_index, drop_edge_rate_1, walk_length)
    edge_index_4, walk_nodes2 = dropout_path(data.edge_index, drop_edge_rate_2, walk_length)

    x_1 = drop_feature(data.x, drop_feature_rate_1)  # 3
    x_2 = drop_feature(data.x, drop_feature_rate_2)  # 4

    # x_1 = drop_node_features_by_index(data.x, walk_nodes1, drop_feature_rate_1)#3
    # x_2 = drop_node_features_by_index(data.x, walk_nodes2, drop_feature_rate_1)#4

    # z1 = model(x_1, edge_index_1)
    # z2 = model(x_2, edge_index_2)

    z3 = model(x_1, edge_index_3)
    z4 = model(x_2, edge_index_4)

    z5 = model(data.x, data.edge_index)


    loss1 = model.loss(z3+z4, z5)
    #
    # loss1 = model.loss(z1, z2)

    loss2 = model.fa_loss(z3, z4)

    # loss = loss1
    loss = loss1 + loss2
    loss.backward()
    optimizer.step()

    return loss.item()


from sklearn.manifold import TSNE
import matplotlib.pyplot as plt


def plot_points(embedding, labels):
    tsne = TSNE(n_components=2, init='pca', random_state=42)
    x_tsne = tsne.fit_transform(embedding)
    plt.figure(figsize=(5, 5))
    plt.subplot(111)
    plt.scatter(x_tsne[:, 0], x_tsne[:, 1], c=labels)
    plt.xlabel('(d)DAGCL')
    plt.show()

def test():
    model.eval()
    z = model(data.x, data.edge_index)
    # plot_points(z.cpu().detach().numpy(), data.y.cpu())
    evaluator = MulticlassEvaluator()
    if args.dataset == 'WikiCS':
        accs = []
        accs_1 = []
        accs_2 = []
        for i in range(20):
            acc = log_regression(z, dataset, evaluator, split=f'wikics:{i}', num_epochs=800)['acc']
            accs.append(acc)
        acc = sum(accs) / len(accs)
    else:
        if args.dataset == 'Cora' or args.dataset == 'CiteSeer' or  args.dataset == 'PubMed':
            acc = log_regression(z, dataset, evaluator, split='preloaded', num_epochs=3000, preload_split=split)['acc']
            # acc = log_regression(z, dataset, evaluator, split='rand:0.3', num_epochs=3000, preload_split=0)['acc']
        else : acc = log_regression(z, dataset, evaluator, split='rand:0.1', num_epochs=3000, preload_split=0)['acc']
        #acc_2 = log_regression(z2, dataset, evaluator2, split='rand:0.1', num_epochs=3000, preload_split=split)['acc']

    # if final and use_nni:
        nni.report_final_result(acc)
    # elif use_nni:
        nni.report_intermediate_result(acc)

    return acc#, acc_1, acc_2

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--device', type=str, default='cuda:0')
    parser.add_argument('--dataset', type=str, default='Cora')
    parser.add_argument('--config', type=str, default='param.yaml')
    parser.add_argument('--seed', type=int, default='0')
    parser.add_argument('--verbose', type=str, default='train,eval,final')
    parser.add_argument('--save_split', type=str, nargs='?')
    parser.add_argument('--load_split', type=str, nargs='?')
    parser.add_argument("--repetition_cluster", type=int, default=10, help='Repetition of clustering')
    args = parser.parse_args()

    config = yaml.load(open(args.config), Loader=SafeLoader)[args.dataset]

    torch.manual_seed(args.seed)
    random.seed(0)
    np.random.seed(args.seed)
    # seed= args.seed==config['seed']
    use_nni = args.config == 'nni'
    learning_rate = config['learning_rate']
    num_hidden = config['num_hidden']
    num_proj_hidden = config['num_proj_hidden']
    activation = config['activation']
    base_model = config['base_model']
    num_layers = config['num_layers']
    dataset = args.dataset
    drop_edge_rate_1 = config['drop_path_rate_1']
    drop_edge_rate_2 = config['drop_path_rate_2']
    walk_length = config['walk_length']
    drop_feature_rate_1 = config['drop_feature_rate_1']
    drop_feature_rate_2 = config['drop_feature_rate_2']
    drop_scheme = config['drop_scheme']
    tau = config['tau']
    num_epochs = config['num_epochs']
    weight_decay = config['weight_decay']
    # rand_layers = config['rand_layers']

    device = torch.device(args.device)

    path = osp.expanduser('~/datasets')
    path = osp.join(path, args.dataset)
    dataset = get_dataset(path, args.dataset)
    
    data = dataset[0]
    data = data.to(device)
    
    if args.dataset == 'Cora' or args.dataset == 'CiteSeer' or  args.dataset == 'PubMed':
        split = (data.train_mask, data.val_mask, data.test_mask)

    encoder = Encoder(dataset.num_features, num_hidden, get_activation(activation),
                      base_model=GCNConv, k=num_layers).to(device)

    model = GRACE(encoder, num_hidden, num_proj_hidden,tau).to(device)
    
    optimizer = torch.optim.Adam(
        model.parameters(),
        lr=learning_rate,
        weight_decay=weight_decay
    )   

    log = args.verbose.split(',')

    for epoch in range(1, num_epochs + 1):

        loss = train()
        if 'train' in log:
            print(f'(T) | Epoch={epoch:03d}, loss={loss:.4f}')
        if epoch % 100 == 0:
            acc = test()
            # x_1 = drop_feature(data.x, drop_feature_rate_1)#3
            # x_2 = drop_feature(data.x, drop_feature_rate_2)#4

            edge_index_1, walk_nodes1 = dropout_path(data.edge_index, p=drop_edge_rate_1)
            edge_index_2, walk_nodes2 = dropout_path(data.edge_index, p=drop_edge_rate_2)

            x_1 = drop_node_features_by_index(data.x, walk_nodes1, drop_feature_rate_1)  # 3
            x_2 = drop_node_features_by_index(data.x, walk_nodes2, drop_feature_rate_2)  # 4

            # edge_index_4 = dropout_new_path(data.edge_index,p=drop_edge_rate_1, wl= walk_length)[0]  # adjacency with edge droprate 2
            # edge_index_3 = dropout_new_path(data.edge_index,p=drop_edge_rate_2, wl= walk_length)[0]

            # edge_index_1 = dropout_edge(data.edge_index, p=drop_edge_rate_1)[0]  # adjacency with edge droprate 2
            # edge_index_2 = dropout_edge(data.edge_index, p=drop_edge_rate_2)[0]
            # adjacency with edge droprate 2
            z = model(data.x, data.edge_index).detach().cpu().numpy()

            # z3 = model(x_1, edge_index_3).detach().cpu().numpy()
            # z4 = model(x_2, edge_index_4).detach().cpu().numpy()
            #
            z1 = model(x_1, edge_index_1).detach().cpu().numpy()
            z2 = model(x_2, edge_index_2).detach().cpu().numpy()

            # 计算欧几里德距离
            # distance51 = euclidean_distance(z3, z4)
            # print("PP:", distance51)
            # distance52 = cos(z1.reshape(1, -1), z2.reshape(1, -1))
            # print("EE:", distance52)


        # np.save('embedding/' + args.dataset + 'Graph_embeddingview1.npy', z3)
        #     np.save('embedding/' + args.dataset + 'Graph_embeddingview2.npy', z4)
        #     np.save('embedding/'+args.dataset + 'Graph_embeddingfull.npy', z)
        #     if 'eval' in log:
        #         print(f'(E) | Epoch={epoch:04d}, avg_acc = {acc}')



    acc = test()

    # z = model(data.x, data.edge_index)
    # plot_points(z.cpu().detach().numpy())
    # print("=== Node clustering evaluation ===")
    # nmi, nmi_std, ari, ari_std = evaluate_clustering(z.cpu().detach().numpy(), 8, data.y.cpu(), args.repetition_cluster)
    # print('nmi:{:.4f}, nmi std:{:.4f}, ari:{:.4f}, ari std:{:.4f}'.format(nmi, nmi_std, ari, ari_std))

    f = open("result_" + args.dataset + ".txt", "a")
    f.write(str(acc) + "\n")
    f.close()
    # 保存模型训练好的权重
    # torch.save(model.state_dict(), 'save.pt')
    # model.load_state_dict(torch.load("save.pt"))


    if 'final' in log:
        print(f'{acc}')




