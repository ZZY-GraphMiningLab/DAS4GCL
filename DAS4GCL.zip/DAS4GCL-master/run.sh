#!/bin/bash
#DSUB -n job_test
#DSUB -N 1
#DSUB -A root.ysuanAJ15z
#DSUB -R "cpu=128;gpu=4;mem=260000"
#DSUB -oo %J.out
#DSUB -eo %J.err

#修改test.py为您自己的算例文件
python main.py --dataset Amazon-Computers
